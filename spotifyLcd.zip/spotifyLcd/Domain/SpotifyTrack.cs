﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace spotifyLcd.Domain
{
    public class SpotifyTrack
    {
        public string Artist { get; set; }
        public string Track { get; set; }
    }
}
